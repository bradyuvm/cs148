<!-- %%%%%%%%%%%%%%%%%%%%%%     Page header   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% -->

<header>
    <figure class="float_left small">
            <img alt="calvin and hobbes has influenced my snowman making." src="images/snowmen.jpg">
            <figcaption>Snowmen observing an accident.</figcaption>
    </figure>
    <h1>Main title for SITE</h1>
    <h2>Tag line</h2>
</header>

<!-- %%%%%%%%%%%%%%%%%%%%% Ends Page header   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% -->